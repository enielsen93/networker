# networker
Python Package for analyzing fromnode and tonode in a Mike Urban Database

<b>To install:</b>

```
python -m pip install https://github.com/enielsen93/networker/tarball/master
```
